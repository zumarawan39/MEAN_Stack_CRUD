const express = require("express");
const route   = express.Router();
const path=require("path");
let {show,post,deleteCard,editCard}=require("../controllers/crud");

route.get("/get",show)
route.post("/post",post);
route.delete(`/delete/:id`,deleteCard)
route.patch(`/edit/:id`,editCard)

module.exports=route;