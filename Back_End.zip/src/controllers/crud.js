const {saveData,showData,deleteItem,updateItem} = require("../modals/sign_up");

let post=async(req,res)=>{
  let {f_name,email}=req.body;
  await saveData(f_name,email );
}
let show=async(req,res)=>{
try {
  let data=await showData();
await res.json(data);
return data;
} catch (error) {
  console.log("Here is server error",error);
}
}
let deleteCard = async (req, res) => {
  let itemId = req.params.id;  
  let delItem=await deleteItem(itemId); 
  res.json(delItem);
};
const editCard = async (req, res) => {
  try {
      let itemId = req.params.id;
      let newData = req.body; 
      let updatedItem = await updateItem(itemId, newData);
      res.json({ message: "Item updated successfully", updatedItem });
      console.log("after updated",updatedItem);
  } catch (error) {
      console.error("Error while updating item:", error);
      res.status(500).json({ error: "Internal server error" });
  }
};
module.exports={post,show,deleteCard,editCard};