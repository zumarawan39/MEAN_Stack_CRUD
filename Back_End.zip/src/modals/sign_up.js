  let mongoose=require("mongoose");
  let schema=mongoose.Schema({
      f_name:String,
      email:String,
  })
  let modal=mongoose.model("angular_sign_up",schema);
  let url="mongodb+srv://seebizbpt0623evdev41:l2Be11O5zei97LtK@tasks.fkxsczr.mongodb.net/"
  let saveData=async(f_name,email)=>{
  await mongoose.connect(url);
  let user=new modal({
    f_name:f_name,
    email:email
  })
  await user.save();
  console.log("checkuser",user);
  return user;
  }
  let showData=async()=>{
    await mongoose.connect(url);
    let user=await modal.find();
    console.log("======",user);
    return user;
  }
  let deleteItem = async (itemId) => {
    await mongoose.connect(url);
      let delItem=await modal.findByIdAndDelete(itemId);
      console.log("db  deleted",delItem);
      return delItem;
  };

  const updateItem = async (itemId, newData) => {
    await mongoose.connect(url);
    let updatedItem = await modal.findByIdAndUpdate(itemId, newData, { new: true });
    console.log("Updated item:", updatedItem);
    return updatedItem;
};
  module.exports={saveData,showData,deleteItem,updateItem}