import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../Services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-angular-crud',
  templateUrl: './angular-crud.component.html',
  styleUrls: ['./angular-crud.component.css']
})
export class AngularCrudComponent implements OnInit {
  add_Form!: FormGroup;
  constructor(private apiService: ApiService , private route:Router) {}
  items: any[] = [];
  ngOnInit(): void {
    this.add_Form = new FormGroup({
      f_name: new FormControl('', [Validators.required]),
      email: new FormControl('', [Validators.required]),
    });
  }

  getData(): void {
    this.apiService.getAll().subscribe(
      (data) => {
        console.log(data);
        
        this.items = data;
      },
      (error) => {
        console.error('Error fetching data', error);
      }
    );
  }
  addData(): void {
    let formData=this.add_Form.value
    this.apiService.create(formData).subscribe(
      (res) => {
        this.route.navigate(['/show']);  
        this.getData();
      },
      (error) => {
        console.error(error);
      }
    );

    console.log(this.add_Form.value);
  }
}
