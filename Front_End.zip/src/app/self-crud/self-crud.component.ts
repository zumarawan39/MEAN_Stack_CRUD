import { Component } from '@angular/core';

@Component({
  selector: 'app-self-crud',
  templateUrl: './self-crud.component.html',
  styleUrl: './self-crud.component.css'
})
export class SelfCrudComponent {

}
