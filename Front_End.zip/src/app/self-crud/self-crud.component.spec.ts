import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelfCrudComponent } from './self-crud.component';

describe('SelfCrudComponent', () => {
  let component: SelfCrudComponent;
  let fixture: ComponentFixture<SelfCrudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SelfCrudComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SelfCrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
