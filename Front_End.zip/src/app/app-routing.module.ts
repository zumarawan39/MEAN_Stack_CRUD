import { NgModule } from '@angular/core';

import { AngularCrudComponent } from './angular-crud/angular-crud.component';
import { AddDataComponent } from './add-data/add-data.component';
import { ShowDataComponent } from './show-data/show-data.component';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';
import { EditComponentComponent } from './edit-component/edit-component.component';


const routes: Routes=[
  {path:"",component:AngularCrudComponent},
  {path:"home",component:AngularCrudComponent},
  {path:"add",component:AddDataComponent},
  {path:"show",component:ShowDataComponent},
  {path:"edit",component:EditComponentComponent},
  {path:"**",component:NotFoundComponent}
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
