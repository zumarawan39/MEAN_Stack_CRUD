import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../Services/api.service';

@Component({
  selector: 'app-edit-component',
  templateUrl: './edit-component.component.html',
  styleUrls: ['./edit-component.component.css']
})
export class EditComponentComponent implements OnInit {
  signupForm: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<EditComponentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private formBuilder: FormBuilder,
    private apiService: ApiService
  ) {
    this.signupForm = this.formBuilder.group({
      f_name: [data.user.f_name, [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
      email: [data.user.email, [Validators.required, Validators.email]]
    });
  }

  ngOnInit(): void {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    // if (this.signupForm.valid) {
    let data=this.signupForm.value;
    let itemId=this.data.user._id;
      this.apiService.updateData(itemId,data ).subscribe(response => {
        this.dialogRef.close(response);

      });
      this.dialogRef.afterClosed().subscribe((res)=>{
        console.log(res,"========");
        if(res){
          this.apiService.getAll();
        }
      })
    // }
  }
}
