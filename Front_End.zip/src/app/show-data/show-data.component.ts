import { Component, OnInit } from '@angular/core';
import { ApiService } from '../Services/api.service';
import { Router } from '@angular/router'; 
import { MatDialog } from '@angular/material/dialog';
import { EditComponentComponent } from '../edit-component/edit-component.component';

@Component({
  selector: 'app-show-data',
  templateUrl: './show-data.component.html',
  styleUrls: ['./show-data.component.css']
})
export class ShowDataComponent implements OnInit {
  data: any[] = [];

  constructor(
    private apiService: ApiService,
    private route: Router,
    public dialog: MatDialog,
  ) {}

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.apiService.getAll().subscribe(
      (response) => {
        this.data = response;
      },
      (error) => {
        console.error('Error fetching data:', error);
      }
    ); 
  }

  updateItem(user: any) {
    console.log("edit clicked");
    const dialogRef = this.dialog.open(EditComponentComponent, {
      width: '300px',
      panelClass: 'custom-dialog-container',
      position: { left: '40%' },
      data: { user }
    });

    dialogRef.afterClosed().subscribe((updatedUser) => {
      if (updatedUser) {
        const index = this.data.findIndex(item => item._id === updatedUser._id);
        if (index !== -1) {
          this.data[index] = updatedUser;
        }
      }
    });
  }

  deleteItem(itemId: string) {
    this.apiService.deleteAll(itemId).subscribe(
      (res) => {
        console.log('Item deleted successfully:', res);
        this.data = this.data.filter(item => item._id !== itemId);
      },
      (error) => {
        console.error('Error deleting item:', error);
      }
    );
  }
}
